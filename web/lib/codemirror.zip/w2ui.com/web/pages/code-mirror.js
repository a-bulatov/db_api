// Code Mirror

$(function () {
	// html
	$("textarea.html").each(function (index, el) {
		let cm = CodeMirror.fromTextArea(this, {
			mode		: "htmlmixed",
			readOnly	: true,
			gutter		: true,
			lineNumbers	: true
		})
		cm.setSize(null, cm.doc.height + 15)
	})

	// javascript
	$("textarea.javascript").each(function (index, el) {
		let cm = CodeMirror.fromTextArea(this, {
			mode		: "javascript",
			readOnly	: true,
			gutter		: true,
			lineNumbers	: true
		})
		cm.setSize(null, cm.doc.height + 15)
	})

	// css
	$("textarea.css").each(function (index, el) {
		let cm = CodeMirror.fromTextArea(this, {
			mode		: "css",
			readOnly	: true,
			gutter		: true,
			lineNumbers	: true
		})
		cm.setSize(null, cm.doc.height + 15)
	})

	// less
	$("textarea.less").each(function (index, el) {
		let cm = CodeMirror.fromTextArea(this, {
			mode		: "less",
			readOnly	: true,
			gutter		: true,
			lineNumbers	: true
		})
		cm.setSize(null, cm.doc.height + 15)
	})
})